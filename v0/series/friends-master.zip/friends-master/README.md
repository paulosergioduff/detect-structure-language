# friends
[Friends Transcripts](https://fangj.github.io/friends/)  
[friends.mobi](https://fangj.github.io/friends/friends.mobi)

